# Inkbeat project — local render route (verified 2026-11-22)
- Remotion's bundled chrome-headless-shell FAILS here: --gl=angle gives "Error creating WebGL context", --gl=swangle hangs the page past 240s.
- WORKING: full Playwright Chromium + angle:
  npx remotion still src/index.ts Demo out/demo.jpg --scale=0.5 --gl=angle --timeout=240000 --browser-executable=$HOME/.cache/ms-playwright/chromium-1148/chrome-linux/chrome
  (~80s per still at scale 0.5 on this VM; typecheck passes clean)
- Demo stills rendered + eye-checked 2026-11-22: out/demo.jpg (day), out/demo-hero.jpg (dusk, BAKERY tag), out/demo-cast.jpg (elder/adult/kid family).
