// "The Great Molasses Flood" — inkbeat Short #1. One continuous beat-rig camera (no hard cuts), shots and
// captions anchored to the N1 voice-over words via src/plan.gen.ts (plan/plan_src.py). Everything is a pure
// function of t: wave advance, surge, the worker's climb, floating debris, the tank's lean.
import React from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from "remotion";
import * as THREE from "three";
import { CAST } from "./inkbeat/char/cast";
import { Character3D, headOf } from "./inkbeat/char/Character3D";
import { Captions, makeChunks } from "./inkbeat/core/captions";
import type { Word } from "./inkbeat/core/captions";
import { CastLight } from "./inkbeat/core/castLight";
import { subFrame, useFonts } from "./inkbeat/core/frame";
import { boxG, cylG, Label, M } from "./inkbeat/core/kit";
import { LiquidPool, LiquidPour, LiquidWave } from "./inkbeat/core/liquid";
import { moodOf } from "./inkbeat/core/moods";
import { aim, poseAt, withShake } from "./inkbeat/core/rig";
import type { Beat, BeatPrm, Cam } from "./inkbeat/core/rig";
import { View } from "./inkbeat/core/View";
import type { V3 } from "./inkbeat/types";
import { ACCENT_WORDS, DURATION, WORDS } from "./plan.gen";
import { Barrel, Crate, Street } from "./demo/Street";

const FPS = 30;
const DUR_S = DURATION / FPS;
const CHUNKS = makeChunks(WORDS as unknown as Word[], DUR_S);
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const sstep = (a: number, b: number, t: number) => { const u = clamp((t - a) / (b - a)); return u * u * (3 - 2 * u); };
const mix3 = (a: V3, b: V3, u: number): V3 => [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u];

// key word times (s, from the real line timings in plan.gen)
const T_TSUNAMI = 1.01, T_BURST = 5.97, T_WAVE = 6.86, T_RACED = 10.72, T_GOLD = 16.57;

// ------------------------------------------------------------------ the tank (the key object)
const Tank: React.FC<{ t: number }> = ({ t }) => {
  const lean = 0.055 * sstep(T_BURST, T_BURST + 2.2, t);
  return (
    <group position={[-5.6, 0.16, -10.6]} rotation={[0, 0, lean]}>
      <M g={cylG(2.3, 2.3, 7.6, 28)} c="#74513a" tex="metal" p={[0, 3.8, 0]} />
      <M g={cylG(2.36, 2.36, 0.22, 28)} c="#4a4a52" tex="metal" p={[0, 7.65, 0]} />
      <M g={cylG(2.36, 2.36, 0.22, 28)} c="#4a4a52" tex="metal" p={[0, 0.6, 0]} />
      <M g={cylG(2.36, 2.36, 0.22, 28)} c="#4a4a52" tex="metal" p={[0, 4.0, 0]} />
      <M g={boxG(0.5, 7.6, 0.5)} c="#4a4a52" tex="metal" p={[-2.15, 3.8, 0.4]} />
      <M g={boxG(0.5, 7.6, 0.5)} c="#4a4a52" tex="metal" p={[2.15, 3.8, 0.4]} />
    </group>
  );
};

// ------------------------------------------------------------------ the wave, a pure function of t
const waveFront = (t: number) => -6.5 + 8.8 * Math.pow(clamp((t - T_BURST) / 7.5), 0.85); // the FACE plane, travelling +x down the street from the tank
const waveH = (t: number) => {
  const growth = sstep(T_BURST - 0.1, T_BURST + 1.0, t);
  const surge = 0.5 + 0.5 * Math.sin(2 * Math.PI * 0.45 * (t - T_WAVE) + 1);
  return (3.35 + 0.9 * surge) * growth;
};
const Wave: React.FC<{ t: number }> = ({ t }) => {
  if (t < T_BURST - 0.15) return null;
  const settle = sstep(15.8, 17.4, t);
  const front = waveFront(t);
  return (
    <group>
      <LiquidWave p={[front - 2.3, 0.16, -3.4]} w={9} h={waveH(t)} t={t} yaw={Math.PI / 2} settle={settle} color="#40200e" glint="#c98a48" edge="#7a4416" drips={6} splash={9} />
      {t > 6.8 ? <LiquidPool p={[front - 1.6, 0.185, -3.4]} r={1.2 + 2.6 * sstep(6.8, 15, t)} t={t} sx={1.1} sz={1.5} color="#341a09" glint="#c98a48" edge="#7a4416" /> : null}
      {t > 13.5 ? <LiquidPool p={[0.3, 0.19, -1.2]} r={1.6 + 1.7 * sstep(13.5, 17, t)} t={t} sx={1.3} sz={0.7} color="#2e1708" glint="#c98a48" edge="#7a4416" /> : null}
      {t > T_BURST && t < T_BURST + 2.4 ? <LiquidPour from={[-4.2, 2.4, -8.6]} to={[-2.4, 0.3, -6.6]} r0={0.34} r1={0.55} t={t} arch={0.7} color="#40200e" glint="#c98a48" edge="#7a4416" /> : null}
    </group>
  );
};

// debris that the front lifts and tilts as it passes (pure function of t)
const Debris: React.FC<{ t: number }> = ({ t }) => {
  const front = waveFront(t);
  const lift = (x: number, seed: number) => {
    const k = clamp((front - (x - 0.8)) / 2.2) * (t > T_BURST ? 1 : 0);
    return { k, y: k * (0.85 + 0.22 * Math.sin(t * 1.3 + seed)), rz: k * 0.38 * Math.sin(t * 0.9 + seed * 2), dx: k * 0.9 };
  };
  const a = lift(-3.4, 1.7), b = lift(-1.2, 4.1);
  return (
    <group>
      <group position={[-3.4 + a.dx, 0.16 + a.y, -4.6]} rotation={[0, 0.4, a.rz]}><Crate p={[0, 0, 0]} s={0.55} yaw={0.4} /></group>
      <group position={[-1.2 + b.dx, 0.16 + b.y, -2.4]} rotation={[b.rz, 0, b.rz * 0.7]}><Barrel p={[0, 0, 0]} /></group>
    </group>
  );
};

// ------------------------------------------------------------------ cast paths
const workerPos = (t: number): V3 => {
  const up = sstep(8.6, 10.6, t); // scrambles onto the crate stack as the front closes in
  const down = sstep(16.6, 17.9, t); // climbs back down for the golden payoff
  return mix3(mix3([0.2, 0.16, -2.6], [3.4, 1.91, -3.2], up), [1.15, 0.16, -2.3], down);
};
const WORKER = CAST.adult, KID = CAST.kid, ELDER = CAST.elder;

// ------------------------------------------------------------------ camera: one rig, beats on words
const headA = headOf([0.2, 0.16, -2.6], WORKER.height, WORKER.build);
const CAM_A = aim([1.25, 1.5, 0.75], headA, 46, 0.38);
const CAM_B: Cam = { pos: [4.8, 3.6, 9.4], look: [0.2, 1.5, -6.8], fov: 56, roll: 0 };
const CAM_C: Cam = { pos: [0.2, 1.5, 5.6], look: [-0.6, 1.5, -4.4], fov: 56, roll: 0 };
const CAM_D: Cam = { pos: [1.2, 2.6, 7.4], look: [1.8, 0.9, -3.2], fov: 50, roll: 0 };
const CAM_E: Cam = { pos: [0.4, 1.9, 4.6], look: [0.1, 1.05, -2.7], fov: 50, roll: 0 };
const BEATS: Beat[] = [
  { t: T_TSUNAMI - 0.06, move: "PUNCH", dur: 0.2, word: "tsunami." },
  { t: 1.55, move: "TO", dur: 1.5, word: "molasses." },
  { t: 3.2, move: "ORBIT_L", dur: 0.63 },
  { t: 4.3, move: "PUSH", dur: 0.63 },
  { t: 5.35, move: "PUSH", dur: 0.63 },
  { t: T_BURST, move: "SHAKE", dur: 0.4, word: "burst," },
  { t: 6.55, move: "TO", dur: 1.1, word: "wave," },
  { t: 7.9, move: "ORBIT_R", dur: 0.63 },
  { t: 9.0, move: "PUSH", dur: 0.63 },
  { t: 10.0, move: "DOLLY_R", dur: 0.63 },
  { t: T_RACED, move: "TO", dur: 1.2, word: "raced" },
  { t: 12.2, move: "PUSH", dur: 0.63 },
  { t: 13.4, move: "ORBIT_L", dur: 0.63 },
  { t: 14.6, move: "PUSH", dur: 0.63 },
  { t: 15.7, move: "DOLLY_L", dur: 0.63 },
  { t: T_GOLD, move: "TO", dur: 1.3, word: "strangest" },
  { t: 18.2, move: "PUSH", dur: 0.63 },
  { t: 19.15, move: "PUSH", dur: 0.63 },
];
const PRMS: BeatPrm[] = [
  { frac: 0.1 }, { to: CAM_B, dur: 1.5 }, { deg: 10 }, { frac: 0.12 }, { frac: 0.1 }, {},
  { to: CAM_C, dur: 1.1 }, { deg: 12 }, { frac: 0.14 }, { side: 0.8 },
  { to: CAM_D, dur: 1.2 }, { frac: 0.12 }, { deg: 10 }, { frac: 0.12 }, { side: 0.6 },
  { to: CAM_E, dur: 1.3 }, { frac: 0.1 }, { frac: 0.08 },
];

export const MolassesInner: React.FC<{ sub?: boolean }> = ({ sub = false }) => {
  const ready = useFonts();
  const g = useCurrentFrame();
  if (!ready) return <AbsoluteFill style={{ background: "#141820" }} />;
  const { n, fp } = sub ? subFrame(g) : { n: g, fp: g };
  const t = fp / FPS;
  const mood = moodOf(t < T_GOLD ? "cold" : "golden");
  const p = poseAt(CAM_A, BEATS, 0, t, PRMS);
  const cam = withShake(p, p.shake);
  const wPos = workerPos(t);
  const wHead = headOf(wPos, WORKER.height, WORKER.build);
  const climbing = (t > 8.6 && t < 10.6) || (t > 16.6 && t < 17.9);
  const face = t < T_TSUNAMI ? { eyes: "open" as const, mouth: "smile" as const, brows: "raised" as const }
    : t < 2.4 ? { eyes: "wide" as const, mouth: "o" as const, brows: "raised" as const, sweat: true }
    : t < T_WAVE ? { eyes: "open" as const, mouth: "frown" as const, brows: "worried" as const, look: 0.6 }
    : t < 12 ? { eyes: "wide" as const, mouth: "open" as const, brows: "worried" as const, sweat: true }
    : t < T_GOLD ? { eyes: "open" as const, mouth: "flat" as const, brows: "worried" as const }
    : { eyes: "open" as const, mouth: "smile" as const, brows: "raised" as const };
  return (
    <AbsoluteFill style={{ background: "#141820" }}>
      <View mood={mood} cam={cam} t={t} focus={wHead} blur={1.2}>
        <Street shopSign="BOSTON 1919" lamp={0} />
        <Tank t={t} />
        <Label text="2M GALLONS" p={[-5.6, 5.1, -8.24]} w={3.2} h={0.66} fg="#f4ead6" bg="#3a2a1a" font={0.6} />
        {/* the worker's crate stack */}
        <Crate p={[3.4, 0.16, -3.2]} s={0.95} yaw={0.15} />
        <Crate p={[3.4, 1.11, -3.2]} s={0.8} yaw={-0.2} />
        <Wave t={t} />
        <Debris t={t} />
        <Character3D {...WORKER} position={wPos} yaw={climbing ? 1.15 : t >= T_GOLD ? -0.3 : 0.45} t={t} face={face}
          pose={climbing ? { walk: t * 7, armL: [30, 40], armR: [30, 40], headTilt: -4 }
            : t >= 9.4 && t < 16.6 ? { armL: [10, 10], armR: [150, 30], armRFwd: 20, headTilt: -4 }
            : { armL: [10, 10], armR: [62, 72], armRFwd: 34, headTilt: -4 }}
          faceCamera={cam.pos} />
        {t >= T_GOLD ? (
          <>
            <Character3D {...ELDER} position={[-1.45, 0.16, -2.1]} yaw={0.5} t={t} face={{ eyes: "open", mouth: "smile", brows: "raised" }} pose={{ armL: [10, 10], armR: [40, 50], armRFwd: 24 }} faceCamera={cam.pos} />
            <Character3D {...KID} position={[-0.65, 0.16, -3.05]} yaw={0.35} t={t} face={{ eyes: "open", mouth: "grin", brows: "raised" }} pose={{ armL: [20, 20], armR: [55, 60], armRFwd: 30 }} faceCamera={cam.pos} />
          </>
        ) : null}
        <CastLight at={wHead} cam={cam.pos} mood={mood} />
      </View>
      <Captions chunks={CHUNKS} t={n / FPS} accent={new Set(ACCENT_WORDS)} until={DUR_S - 0.35} />
      {!sub ? <Audio src={staticFile("soundtrack.wav")} /> : null}
    </AbsoluteFill>
  );
};
void THREE;
