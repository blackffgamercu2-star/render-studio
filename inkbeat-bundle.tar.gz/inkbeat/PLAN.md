# PLAN — "The Great Molasses Flood" (inkbeat Short #1)
Topic picked by Muse (Abid: "topic koi sa bhi utha lo"), voice N1. True story: Boston, 15 Jan 1919.

- Duration: 19.74 s (picture ends ~0.7 s after the last word) · 1080x1920 · 30 fps
- Voice: N1 Confident Chime (avocado_v2:casper_1_25x), Muse TTS, speed 118, single narrator, English
  - line timings are REAL (each line generated separately, silence-trimmed, speech spans measured);
    word onsets inside a line are distributed by word length (approximation, disclosed)
- Shots (word-anchored, plan/plan_src.py):
  - S01 0.00 cold — close on the worker; on "tsunami." (1.01) PUNCH + shocked face (wide eyes, "o" mouth)
  - S02 2.37 cold — on "molasses." fast pull-out `to` wide: the giant tank + street revealed (key object on screen ~1.5 s)
  - S03 6.86 cold — the wave act: LiquidWave, dark glossy syrup, surge height ~4.4-5.2 m, drips + splash;
    on "burst," (5.97) SHAKE; crates/barrel in its path lift and tilt as the front passes (pure function of t)
  - S04 10.72 cold — tracking dolly with the racing front; the worker scrambles onto a crate stack (walk phase, 8.2-10 s climb)
  - S05 16.57 golden — payoff: settled pool, elder + kid join, faint sweet-smell wisps (Smoke, pale gold, beside faces, never across)
- Camera: ONE continuous rig (poseAt), no hard cuts; beats ~every 0.9-1.1 s (PUSH / ORBIT / DOLLY / PUNCH / WHIP + `to` moves), drift always on
- Tags (unlit, painted in the world): "BOSTON 1919" on the warehouse sign · "2M GALLONS" on the tank
- Captions: plan.gen WORDS -> makeChunks, all white, accents: molasses / wave / strangest
- Audio: voice + original generated music bed (~-14 dB under voice) + burst rumble and wave wash SFX on the exact words, loudnorm -14 LUFS
- QA: flicker.py, analyze_pacing.py, 2 fps contact sheet eye-check, loudness check
